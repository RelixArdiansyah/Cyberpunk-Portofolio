import { motion } from "framer-motion";
import { Github, Linkedin, Mail } from "lucide-react";

export default function PortfolioLanding() {
  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-800 via-fuchsia-600 to-blue-700 opacity-30 blur-3xl animate-pulse"></div>

      <section className="flex flex-col items-center justify-center h-screen text-center relative z-10 px-6">
        <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-wider text-fuchsia-400 drop-shadow-lg">
            M. Riko Ardiansyah
          </h1>
          <p className="mt-4 text-lg md:text-2xl text-gray-300">
            Computer Engineer | Web Developer | Data Enthusiast
          </p>

          <div className="mt-8 flex gap-4 justify-center flex-wrap">
            <a href="/CV-RikoArdiansyahcv.pdf" download className="bg-fuchsia-600 hover:bg-fuchsia-800 text-white px-6 py-3 rounded-2xl shadow-lg">Download CV</a>
            <a href="https://www.linkedin.com/in/riko-ardiansyah-a19254202/" target="_blank" rel="noopener noreferrer" className="bg-blue-600 hover:bg-blue-800 text-white px-6 py-3 rounded-2xl shadow-lg flex items-center gap-2">
              <Linkedin size={20}/> LinkedIn
            </a>
            <a href="https://github.com/RelixArdiansyah" target="_blank" rel="noopener noreferrer" className="bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-2xl shadow-lg flex items-center gap-2">
              <Github size={20}/> GitHub
            </a>
            <a href="mailto:rikodecoder1@gmail.com" className="bg-red-600 hover:bg-red-800 text-white px-6 py-3 rounded-2xl shadow-lg flex items-center gap-2">
              <Mail size={20}/> Email
            </a>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
