# Cyberpunk Portfolio - Riko

Portfolio web bertema cyberpunk dibuat dengan React + Vite + Tailwind + Framer Motion.

## 🚀 Cara Jalankan
```bash
npm install
npm run dev
```
Lalu buka `http://localhost:5173`.

## 🌐 Deploy
- Upload ke GitHub repo
- Hubungkan ke Netlify/Vercel untuk live demo
